package com.example.smartgarbagesystem.Users;

import android.app.DialogFragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;


import com.example.smartgarbagesystem.Login.SigninActivity;
import com.example.smartgarbagesystem.R;
import com.example.smartgarbagesystem.Users.CollectorFragments.CollectionHistory;
import com.example.smartgarbagesystem.Users.CollectorFragments.CollectionRoute;
import com.example.smartgarbagesystem.Users.CollectorFragments.ExtraRequest;
import com.example.smartgarbagesystem.Users.CollectorFragments.ListRecyclingAgent;
import com.example.smartgarbagesystem.Users.CollectorFragments.Profile;
import com.example.smartgarbagesystem.Users.CollectorFragments.UpcomingSchedule;
import com.example.smartgarbagesystem.Users.OtherFragments.DatePickerFragment;

public class CollectorAgent extends AppCompatActivity implements  NavigationView.OnNavigationItemSelectedListener,CollectionRoute.onFragmentSelected
{
    DrawerLayout drawerLayout;                        //instance of drawer layout.
    ActionBarDrawerToggle actionBarDrawerToggle;      //action bar instance.
    Toolbar toolbar;                                  // toolbar instance.
    NavigationView navigationView;

    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collector_agent);


        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer);
        navigationView = findViewById(R.id.navigationView);
        navigationView.setNavigationItemSelectedListener(CollectorAgent.this);         //to select an option of menu.


        // add all essential item to action bar.
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        actionBarDrawerToggle.syncState();


        //Load the default fragment to the main layout.
        fragmentManager = getSupportFragmentManager();           //instance of fragment.
        fragmentTransaction = fragmentManager.beginTransaction();  //to start some actions.
        fragmentTransaction.add(R.id.frame_layout, new CollectionRoute());  //add the fragment to the frame layout(content of layout).
        fragmentTransaction.commit();                                    //commit the changes.


    }

    //function of onNavigationViewListener interface.
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        drawerLayout.closeDrawer(GravityCompat.START);      //to close navigation view on click.
        if(menuItem.getItemId()==R.id.CollectorCollectionHistory)
        {//call the profile layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new CollectionHistory());
            fragmentTransaction.commit();
        }
        else
        if(menuItem.getItemId()==R.id.CollectorCollectionRoute)
        { //call the History layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new CollectionRoute());
            fragmentTransaction.commit();
        }
        else
        if(menuItem.getItemId()==R.id.CollectorProfile)
        { //call the Bin status layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new Profile());
            fragmentTransaction.commit();
        }
        else
        if(menuItem.getItemId()==R.id.CollectorAboutUs)
        { //call the About us layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new AboutUs());
            fragmentTransaction.commit();
        }
        if(menuItem.getItemId()==R.id.ListOfRecyclingAgent)
        {
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new ListRecyclingAgent());
            fragmentTransaction.commit();
        }
        else
        if(menuItem.getItemId()==R.id.ExtraRequest)
        {
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new ExtraRequest());
            fragmentTransaction.commit();

        }
        if(menuItem.getItemId()==R.id.UpcomingSchedule)
        {
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new UpcomingSchedule());
            fragmentTransaction.commit();
        }
        else
        {
            if(menuItem.getItemId()==R.id.logout)
            {
                startActivity(new Intent(getApplicationContext(),SigninActivity.class));
                finish();
            }
        }
        return true;

    }


    @Override
    public void onTextSelected() {
        startActivity(new Intent(getApplicationContext(), SigninActivity.class));
    }

   /* @Override
    public void pickDate() {
        //DialogFragment datePicker=new DatePickerFragment();
        //datePicker.sh;
    }*/

   /* public void makeCall(View view)
    {
        System.out.println("number:");
        TextView textView=view.findViewById(R.id.textRecyclerPhone2);
        System.out.println("number:"+textView.getText().toString());
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse(textView.getText().toString()));
        startActivity(callIntent);
    }*/
}
