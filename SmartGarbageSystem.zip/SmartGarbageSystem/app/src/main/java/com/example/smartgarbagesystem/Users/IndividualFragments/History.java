package com.example.smartgarbagesystem.Users.IndividualFragments;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.OtherClasses.HistoryListAdapter;
import com.example.smartgarbagesystem.OtherClasses.IndividualHistorySetGetClass;
import com.example.smartgarbagesystem.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.sql.DatabaseMetaData;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class History extends Fragment {
     ListView mlistView=null;
    // DatabaseReference ref=null;
     User user=null;
     static String todayDate=" ";
     static  int i;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.individual_history_fragment,container,false);
        mlistView=view.findViewById(R.id.listview);
        user=new User(getActivity().getApplicationContext());
        System.out.println("enter3");
        setDataInList();
       /* IndividualHistorySetGetClass ih1=new IndividualHistorySetGetClass("Regular","12/may/2020","14/may/2020");
        IndividualHistorySetGetClass ih2=new IndividualHistorySetGetClass("E-waste","13/may/2020","15/may/2020");
        IndividualHistorySetGetClass ih3=new IndividualHistorySetGetClass("Regular","14/may/2020","16/may/2020");
        IndividualHistorySetGetClass ih4=new IndividualHistorySetGetClass("E-waste","15/may/2020","17/may/2020");
        IndividualHistorySetGetClass ih5=new IndividualHistorySetGetClass("Regular","16/may/2020","18/may/2020");

        ArrayList<IndividualHistorySetGetClass> history=new ArrayList<>();
        history.add(ih1);
        history.add(ih2);
        history.add(ih3);
        history.add(ih4);
        history.add(ih5);

        HistoryListAdapter apdapter=new HistoryListAdapter(getActivity().getApplicationContext(),R.layout.individual_history_list_adapter,history);
        mlistView.setAdapter(apdapter);
`           */
        return view;
    }

    public  void setDataInList()
    { i=0;
        System.out.println("enter4");
        System.out.println(user.getId());
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("user").child("Individual");
        ref.orderByChild(user.getId()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(i<1)
                {
                    System.out.println("enter2");
                    setData(dataSnapshot);
                    i++;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public  void setData(DataSnapshot dataSnapshot)
    {
       //System.out.println("enter");
        String collectiondate="";
        ArrayList<IndividualHistorySetGetClass> arrayList=new ArrayList<>();

            System.out.println("user id:"+dataSnapshot.child(user.getId()).getValue());
            if(dataSnapshot.child(user.getId()).child("collection date").child("0").exists())
            {
                //System.out.println("enter if");
                //SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
                //String currentDateandTime = sdf.format(new Date());

                todayDate=dataSnapshot.child(user.getId()).child("collection date").child("0").getValue(String.class);

                collectiondate=dataSnapshot.child(user.getId()).child("collection date").child("1").getValue(String.class);

                arrayList.add(new IndividualHistorySetGetClass("Regular",todayDate,collectiondate));
            }
            if(dataSnapshot.child(user.getId()).child("New Request").exists())
            {
                //System.out.println("enter if");
               // SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
                //String currentDateandTime = sdf.format(new Date());
                String id=dataSnapshot.child(user.getId()).child("New Request").child("Id").getValue(String.class);
                todayDate=dataSnapshot.child(user.getId()).child("New Request").child("Request date").getValue(String.class);

                collectiondate=dataSnapshot.child(user.getId()).child("New Request").child("collection date").getValue(String.class);

                arrayList.add(new IndividualHistorySetGetClass(id,todayDate,collectiondate));
            }


        HistoryListAdapter adapter=new HistoryListAdapter(getActivity().getApplicationContext(),R.layout.individual_history_list_adapter,arrayList);
        mlistView.setAdapter(adapter);
    }
}
