package com.example.smartgarbagesystem.Users.CollectorFragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.OtherClasses.CollectionHistoryAdapter;
import com.example.smartgarbagesystem.OtherClasses.CollectionHistorySetGetClass;
import com.example.smartgarbagesystem.OtherClasses.UpcomingScheduleAdapter;
import com.example.smartgarbagesystem.OtherClasses.UpcomingScheduleSetGetClass;
import com.example.smartgarbagesystem.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UpcomingSchedule extends Fragment {
    User user=null;
    DatabaseReference ref=null;
    ListView listView;
    static int i;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.collector_upcoming_schedule, container, false);
        user=new User(getActivity().getApplicationContext());
        listView=view.findViewById(R.id.listview7);
        setDataInList();

        return view;
    }

    public  void setDataInList()
    { i=0;
        System.out.println("enter4");
        System.out.println(user.getId());
        ref = FirebaseDatabase.getInstance().getReference("user").child("Individual");
        ref.orderByChild(user.getId()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(i<1)
                {
                    System.out.println("enter2");
                    setData(dataSnapshot);
                    i++;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    public  void setData(DataSnapshot dataSnapshot)
    {
        //System.out.println("enter");
        int j=0;
        //String collectiondate="";
        ArrayList<UpcomingScheduleSetGetClass> arrayList=new ArrayList<>();

        for(DataSnapshot dataSnapshot1: dataSnapshot.getChildren())
        {
           if(dataSnapshot1.child("New Request").exists()) {
               //System.out.println("Collection date:" + dataSnapshot1.getValue());
               String value = dataSnapshot1.child("New Request").child("collection date").getValue(String.class);
               System.out.println("value:"+value);
               String collectorname = dataSnapshot1.child("New Request").child("Collector").getValue(String.class);
               System.out.println("collector name:"+collectorname);
               //System.out.println("Collector value:"+Collector);
               if ((value != null && !(value.trim().equals(""))) && (collectorname == null || collectorname.trim().equals(""))
               ||collectorname.equals(user.getUsername())) {
                   System.out.println("enter date!!!!!!!!!!!!!!!!!");
                   String username = dataSnapshot1.child("username").getValue(String.class);
                   String collectionDate = dataSnapshot1.child("New Request").child("collection date").getValue(String.class);
                   System.out.println("username:"+user.getUsername());

                   String key=dataSnapshot1.getKey();
                   System.out.println("key:"+key);
                   ref.child(key).child("New Request").child("Collector").setValue(user.getUsername());
                   //DatabaseReference reference=FirebaseDatabase.getInstance().getReference("user").child("Individual");
                   //reference.child(user.getId()).child("New Request").child("Collector").setValue(user.getUsername());

                   collectorname = dataSnapshot1.child("New Request").child("Collector").getValue(String.class);
                   System.out.println("collector name:"+collectorname);
                   arrayList.add(new UpcomingScheduleSetGetClass("Extra Request", username, collectionDate));
               }
           }
        }




        UpcomingScheduleAdapter adapter=new UpcomingScheduleAdapter(getActivity().getApplicationContext(),R.layout.collector_upcoming_schdule_adapter,arrayList);
        listView.setAdapter(adapter);
    }

}
