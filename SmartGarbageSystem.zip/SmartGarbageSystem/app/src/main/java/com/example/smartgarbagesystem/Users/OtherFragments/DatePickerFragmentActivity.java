package com.example.smartgarbagesystem.Users.OtherFragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smartgarbagesystem.OtherClasses.CollectionExtraRequestAdapter;
import com.example.smartgarbagesystem.R;
import com.example.smartgarbagesystem.Users.CollectorFragments.ExtraRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DatePickerFragmentActivity extends AppCompatActivity {
    TextView textView = null;
    DatePicker picker = null;
    String username, numOfItem;
    DatabaseReference ref = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map_fragment);
        String value = getIntent().getExtras().getString("id");
        username = value.split(" ")[0];
        numOfItem = value.split(" ")[1];
        System.out.println("username:"+username);
        System.out.println("numItem:"+numOfItem);
        //textView=findViewById(id);
        picker = findViewById(R.id.datePicker1);
        Button button = findViewById(R.id.buttonGetDate);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // CollectionExtraRequestAdapter obj=new CollectionExtraRequestAdapter();
                setData(username, numOfItem, picker.getDayOfMonth() + "/" + (picker.getMonth() + 1) + "/" + picker.getYear());
                //
                //finish();
            }
        });
    }

    public void setData(final String username, final String numOfItem, final String date) {
        System.out.println("enter2");
        // final String date=textcollectionDate.getText().toString();
        ref = FirebaseDatabase.getInstance().getReference("user").child("Individual");
        ref.orderByKey().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for (DataSnapshot userDataSnapShot : dataSnapshot.getChildren()) {
                    String key = userDataSnapShot.getKey();
                   // System.out.println("key:" + key);
                    //System.out.println("username" + username + " " + "num of item:" + numOfItem);
                    //System.out.println("date:" + date);
                    //System.out.println(userDataSnapShot.child("username").getValue(String.class));
                    //System.out.println(userDataSnapShot.child("New Request").child("Item").getValue());
                    if (username.equals(userDataSnapShot.child("username").getValue(String.class))
                            && numOfItem.equals(userDataSnapShot.child("New Request").child("Item").getValue(String.class))) {
                        System.out.println("enter, key:" + key);
                        ref.child(key).child("New Request").child("collection date").setValue(date);
                        //CollectionExtraRequestAdapter.setText(picker.getDayOfMonth() + "/" + (picker.getMonth() + 1) + "/" + picker.getYear());
                        Toast.makeText(getApplicationContext(),"Selected date:"+date,Toast.LENGTH_LONG).show();
                        startActivity(new Intent(getApplicationContext(), ExtraRequest.class));
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }


        });
    }
}



