package com.example.smartgarbagesystem.OtherClasses;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.example.smartgarbagesystem.R;
import java.util.List;

public class HistoryListAdapter extends ArrayAdapter<IndividualHistorySetGetClass> {

    private Context context=null;
    int mResource;

    public HistoryListAdapter(Context context, int resource, List<IndividualHistorySetGetClass> objects) {
        super(context, resource, objects);
        this.context = context;
        mResource=resource;

    }



    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater=LayoutInflater.from(context);
        convertView=inflater.inflate(mResource,parent,false);

        String garbageType=getItem(position).getGarbageType();
        String reportDate=getItem(position).getReportDate();
        String collectionDate=getItem(position).getCollectionDate();

        //Create the history object with information
        IndividualHistorySetGetClass history=new IndividualHistorySetGetClass(garbageType,reportDate,collectionDate);



        TextView textGarbage= convertView.findViewById(R.id.textGarbageType);
        TextView textreportdate=convertView.findViewById(R.id.textReportDate);
        TextView textcollectdate=convertView.findViewById(R.id.textCollectionDate);

        textGarbage.setText(garbageType);
        textreportdate.setText(reportDate);
        textcollectdate.setText(collectionDate);

        return convertView;

    }
}
