package com.example.smartgarbagesystem.OtherClasses;

public class IndividualHistorySetGetClass {
    private String garbageType;
    private String reportDate;
    private String collectionDate;

    public IndividualHistorySetGetClass(String garbageType, String reportDate, String collectionDate) {
        this.garbageType = garbageType;
        this.reportDate = reportDate;
        this.collectionDate = collectionDate;
    }



    public String getGarbageType() {
        return garbageType;
    }

    public void setGarbageType(String garbageType) {
        this.garbageType = garbageType;
    }

    public String getReportDate() {
        return reportDate;
    }

    public void setReportDate(String reportDate) {
        this.reportDate = reportDate;
    }

    public String getCollectionDate() {
        return collectionDate;
    }

    public void setCollectionDate(String collectionDate) {
        this.collectionDate = collectionDate;
    }



}
