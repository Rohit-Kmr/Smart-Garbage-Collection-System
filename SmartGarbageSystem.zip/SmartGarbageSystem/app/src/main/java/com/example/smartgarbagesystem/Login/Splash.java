package com.example.smartgarbagesystem.Login;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.example.smartgarbagesystem.MainActivity;
import com.example.smartgarbagesystem.R;
import com.example.smartgarbagesystem.Users.CollectorAgent;
import com.example.smartgarbagesystem.Users.IndividualUser;
import com.example.smartgarbagesystem.Users.OtherFragments.MapFragmentActivity;
import com.example.smartgarbagesystem.Users.RecyclingAgent;

import java.util.Timer;
import java.util.TimerTask;

public class Splash extends AppCompatActivity {

    static int flag=0;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);

        //for permission only.
        if (ContextCompat.checkSelfPermission(Splash.this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(Splash.this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(Splash.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {
                ActivityCompat.requestPermissions(Splash.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
        }


        if (ContextCompat.checkSelfPermission(Splash.this,
                Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)
            {

            Timer timer = new Timer();

            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    User user = new User(Splash.this);
                    user.setUsername("");
                    user.setUserType("");
                    System.out.println("username:"+user.getUsername());
                    System.out.println("usertype:"+user.getUserType());

                    if (user.getUsername() != "" && user.getUserType() != "") {
                        System.out.println("userType=" + user.getUserType());

                        if (user.getUserType().equals("Individual"))
                            startActivity(new Intent(Splash.this, IndividualUser.class));
                        else if (user.getUserType().equals("Collector Agent"))
                            startActivity(new Intent(Splash.this, CollectorAgent.class));
                        else if (user.getUserType().equals("Recycling Agent"))
                            startActivity(new Intent(Splash.this, RecyclingAgent.class));

                    } else {

                        startActivity(new Intent(Splash.this, SigninActivity.class));
                        finish();
                    }
                }

            }, 2000);
        }
    }
        @Override
        public void onRequestPermissionsResult(int requestCode, String[] permissions,
        int[] grantResults) {
            switch (requestCode) {
                case 1: {
                    if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        if (ContextCompat.checkSelfPermission(Splash.this,
                                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                            Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
                            proceddForward();

                        }
                    } else {
                        Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    return;
                }
            }

        }

        public  void proceddForward()
        {
            Timer timer = new Timer();

            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    User user = new User(Splash.this);
                    //user.setUsertype("Individual");
                    if (user.getUsername() != "" && user.getUserType() != "") {
                        System.out.println("userType=" + user.getUserType());

                        if (user.getUserType().equals("Individual"))
                            startActivity(new Intent(Splash.this, IndividualUser.class));
                        else if (user.getUserType().equals("Collector Agent"))
                            startActivity(new Intent(Splash.this, CollectorAgent.class));
                        else if (user.getUserType().equals("Recycling Agent"))
                            startActivity(new Intent(Splash.this, RecyclingAgent.class));

                    } else {

                        startActivity(new Intent(Splash.this, SigninActivity.class));
                        finish();
                    }
                }

            }, 2000);

        }
}
