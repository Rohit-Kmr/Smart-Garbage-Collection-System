package com.example.smartgarbagesystem.Users.CollectorFragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smartgarbagesystem.MainActivity;
import com.example.smartgarbagesystem.OtherClasses.RecyclingAgentListAdapter;
import com.example.smartgarbagesystem.OtherClasses.RecylingAgentListSetGetClass;
import com.example.smartgarbagesystem.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import javax.xml.transform.Templates;

public class ListRecyclingAgent extends Fragment  {

    DatabaseReference ref;
    static int i;
    ListView listView=null;
    TextView textView=null;
    private static final int REQUEST_CALL = 1;
    ArrayList<RecylingAgentListSetGetClass> arrayList;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.collector_list_of_recycling_agent,container,false);

        listView=view.findViewById(R.id.listview3);
        ref=FirebaseDatabase.getInstance().getReference();
        setDataInList();

        return view;
    }

    public  boolean setDataInList()
    {i=0;
        arrayList=new ArrayList<RecylingAgentListSetGetClass>();
        DatabaseReference ref1 = FirebaseDatabase.getInstance().getReference("user").child("Recycling Agent");
        ref1.orderByKey().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(i<1)
                {
                    setData(dataSnapshot);
                    i++;
                }
                }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }



        });
        return  true;

    }

    public void setData(DataSnapshot dataSnapshot)
    {

        for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {

            System.out.println("iter:"+i);

            String name = dataSnapshot.child(userSnapshot.getKey()).child("username").getValue(String.class);
            String address = dataSnapshot.child(userSnapshot.getKey()).child("address").getValue(String.class);
            String phone = dataSnapshot.child(userSnapshot.getKey()).child("phone").getValue(String.class);

            System.out.println("name:"+name);
            System.out.println("address:"+address);
            System.out.println("phone:"+phone);
            RecylingAgentListSetGetClass agentList = new RecylingAgentListSetGetClass(name, address, phone);
            arrayList.add(agentList);
            i++;
        }
        System.out.println("enterSetdata");
        RecyclingAgentListAdapter adapter=new RecyclingAgentListAdapter(getActivity().getApplicationContext(),R.layout.collector_list_of_recyling_agent_adapter,arrayList);
        listView.setAdapter(adapter);
    }





}
