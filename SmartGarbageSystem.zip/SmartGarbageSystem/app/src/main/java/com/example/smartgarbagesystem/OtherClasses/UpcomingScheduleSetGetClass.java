package com.example.smartgarbagesystem.OtherClasses;

public class UpcomingScheduleSetGetClass {
    private  String username;
    private  String requestType;
    private  String collectionDate;


    public UpcomingScheduleSetGetClass(String username, String requestType, String collectionDate) {
        this.username = username;
        this.requestType = requestType;
        this.collectionDate = collectionDate;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getCollectionDate() {
        return collectionDate;
    }

    public void setCollectionDate(String collectionDate) {
        this.collectionDate = collectionDate;
    }
}
