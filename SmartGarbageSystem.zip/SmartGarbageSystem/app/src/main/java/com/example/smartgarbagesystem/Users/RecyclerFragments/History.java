package com.example.smartgarbagesystem.Users.RecyclerFragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.OtherClasses.CollectionHistoryAdapter;
import com.example.smartgarbagesystem.OtherClasses.CollectionHistorySetGetClass;
import com.example.smartgarbagesystem.OtherClasses.RecyclerHistorySetGetClass;
import com.example.smartgarbagesystem.OtherClasses.RecylerHistoryAdapter;
import com.example.smartgarbagesystem.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class History extends Fragment {

    ListView listView=null;
    User user=null;
    static  int i;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.recycler_history_fragment,container,false);
        listView=view.findViewById(R.id.listview6);
        user=new User(getActivity().getApplicationContext());
        setDataInList();
        return view;
    }


    public  void setDataInList()
    { i=0;
        System.out.println("enter4");
        System.out.println(user.getId());
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("user").child("Collector Agent");
        ref.orderByKey().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(i<1)
                {
                    System.out.println("enter2");
                    setData(dataSnapshot);
                    i++;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    public  void setData(DataSnapshot dataSnapshot)
    {
        //System.out.println("enter");
        int j=0;
        //String collectiondate="";
        ArrayList<RecyclerHistorySetGetClass> arrayList=new ArrayList<>();
        // for(DataSnapshot dataSnapshot1:dataSnapshot.getChildren())
        //{

          for(DataSnapshot dataSnapshot1:dataSnapshot.getChildren()) {
              System.out.println(dataSnapshot1.getValue());
              String username = dataSnapshot1.child("username").getValue(String.class);
              //String name = value.split("&&")[0];
              String phone=dataSnapshot1.child("phone").getValue(String.class);

              //String date = value.split("&&")[2];
              arrayList.add(new RecyclerHistorySetGetClass("Garbage Collector",username,phone));
          }





        RecylerHistoryAdapter adapter=new RecylerHistoryAdapter(getActivity().getApplicationContext(),R.layout.recyler_history_adapter,arrayList);
        listView.setAdapter(adapter);
    }
}

