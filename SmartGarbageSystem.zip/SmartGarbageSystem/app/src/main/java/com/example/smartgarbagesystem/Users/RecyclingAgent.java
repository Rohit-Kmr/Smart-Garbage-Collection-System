package com.example.smartgarbagesystem.Users;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.example.smartgarbagesystem.Login.SigninActivity;
import com.example.smartgarbagesystem.R;

import com.example.smartgarbagesystem.Users.RecyclerFragments.History;
import com.example.smartgarbagesystem.Users.RecyclerFragments.Profile;
import com.example.smartgarbagesystem.Users.RecyclerFragments.RecycleItemList;

public class RecyclingAgent extends AppCompatActivity implements  NavigationView.OnNavigationItemSelectedListener,RecycleItemList.onFragmentSelected {
    DrawerLayout drawerLayout;                        //instance of drawer layout.
    ActionBarDrawerToggle actionBarDrawerToggle;      //action bar instance.
    Toolbar toolbar;                                  // toolbar instance.
    NavigationView navigationView;

    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycling_agent);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer);
        navigationView = findViewById(R.id.navigationView);
        navigationView.setNavigationItemSelectedListener(RecyclingAgent.this);         //to select an option of menu.


        // add all essential item to action bar.
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        actionBarDrawerToggle.syncState();


        //Load the default fragment to the main layout.
        fragmentManager = getSupportFragmentManager();           //instance of fragment.
        fragmentTransaction = fragmentManager.beginTransaction();  //to start some actions.
        fragmentTransaction.add(R.id.frame_layout, new History());  //add the fragment to the frame layout(content of layout).
        fragmentTransaction.commit();                                    //commit the changes.


    }

    //function of onNavigationViewListener interface.
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        drawerLayout.closeDrawer(GravityCompat.START);      //to close navigation view on click.
        if(menuItem.getItemId()==R.id.RecyclerHistory)
        {//call the profile layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new History());
            fragmentTransaction.commit();
        }
        else
        if(menuItem.getItemId()==R.id.RecyclerProfile)
        { //call the Collection data layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new Profile());
            fragmentTransaction.commit();
        }
  /*      else
        if(menuItem.getItemId()==R.id.RecyclerItems)
        { //call the History layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new RecycleItemList());
            fragmentTransaction.commit();
        }*/
        else
        if(menuItem.getItemId()==R.id.RecyclerAboutUs)
        { //call the History layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new AboutUs());
            fragmentTransaction.commit();
        }
        else
        {
            if(menuItem.getItemId()==R.id.logout)
            {
                startActivity(new Intent(getApplicationContext(),SigninActivity.class));
                finish();
            }
        }
        return true;

    }


    @Override
    public void onTextSelected() {
        startActivity(new Intent(getApplicationContext(), SigninActivity.class));
    }
}

