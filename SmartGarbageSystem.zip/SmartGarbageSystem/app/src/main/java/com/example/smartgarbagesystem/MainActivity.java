package com.example.smartgarbagesystem;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.design.widget.NavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

import android.view.MenuItem;
import android.widget.TextView;

import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.Users.AboutUs;
import com.example.smartgarbagesystem.Users.IndividualFragments.BinStatus;
import com.example.smartgarbagesystem.Users.IndividualFragments.CollectionDate;
import com.example.smartgarbagesystem.Users.IndividualFragments.History;
import com.example.smartgarbagesystem.Users.IndividualFragments.Profile;


public class MainActivity extends AppCompatActivity{
    DrawerLayout drawerLayout;                        //instance of drawer layout.
    ActionBarDrawerToggle actionBarDrawerToggle;      //action bar instance.
    Toolbar toolbar;                                  // toolbar instance.
    NavigationView navigationView;

    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    User user=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

  }


}


