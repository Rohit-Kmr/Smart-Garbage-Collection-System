package com.example.smartgarbagesystem.Users.CollectorFragments;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smartgarbagesystem.OtherClasses.CollectionExtraRequestAdapter;
import com.example.smartgarbagesystem.OtherClasses.CollectionExtraRequestSetGetClass;
import com.example.smartgarbagesystem.OtherClasses.RecyclingAgentListAdapter;
import com.example.smartgarbagesystem.OtherClasses.RecylingAgentListSetGetClass;
import com.example.smartgarbagesystem.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import java.util.ArrayList;

public class ExtraRequest extends Fragment{
    DatabaseReference ref=null;
    ListView listView=null;
    ArrayList<CollectionExtraRequestSetGetClass> arrayList;
    CollectionExtraRequestAdapter adapter=null;
    static final int DATE_DIALOG_ID = 0;
    static  int i;
    int years,months,days;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.collector_extra_request, container, false);


        listView=view.findViewById(R.id.listview4);
        ref= FirebaseDatabase.getInstance().getReference();
        setDataInList();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                System.out.println("enter onclickListener");
                TextView textView=view.findViewById(R.id.textUsername);
                //Toast.makeText(getActivity().getApplicationContext(), arrayList.get(position)+"", Toast.LENGTH_SHORT).show();
            }
        });
        return view;
    }


    public  boolean setDataInList()
    {i=0;
        arrayList=new ArrayList<CollectionExtraRequestSetGetClass>();
        DatabaseReference ref1 = FirebaseDatabase.getInstance().getReference("user").child("Individual");
        ref1.orderByKey().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(i<1)
                {
                    setData(dataSnapshot);
                    i++;
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }



        });
        return  true;

    }

    public void setData(DataSnapshot dataSnapshot)
    {

        for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {

            System.out.println("iter:"+i);
            if(dataSnapshot.child(userSnapshot.getKey()).child("New Request").exists()) {

                //System.out.println("Extra request:"+dataSnapshot.child(userSnapshot.getKey()).child("password").getValue(String.class));
                String value=dataSnapshot.child(userSnapshot.getKey()).child("New Request").child("collection date").getValue(String.class);
                System.out.println("value date:"+value);
                String collectorname=dataSnapshot.child(userSnapshot.getKey()).child("New Request").child("Collector").getValue(String.class);
                if((value==null || value.trim().equals(""))&&(collectorname==null||collectorname.trim().equals("")))
                {
                    System.out.println("enter");
                    String name = dataSnapshot.child(userSnapshot.getKey()).child("username").getValue(String.class);
                    String numofItem = dataSnapshot.child(userSnapshot.getKey()).child("New Request").child("Item").getValue(String.class);
                    String Itemname = dataSnapshot.child(userSnapshot.getKey()).child("New Request").child("Item Name").getValue(String.class);
                    String ItemDescription = dataSnapshot.child(userSnapshot.getKey()).child("New Request").child("Item Description").getValue(String.class);


                    CollectionExtraRequestSetGetClass agentList = new CollectionExtraRequestSetGetClass(name, numofItem, Itemname, ItemDescription, "");
                    arrayList.add(agentList);
                }
            }

        }
        System.out.println("enterSetdata");
        FragmentManager fragmentManager=getChildFragmentManager();
        adapter=new CollectionExtraRequestAdapter(getActivity().getApplicationContext(),R.layout.collector_extra_request_adapter,arrayList);
        listView.setAdapter(adapter);



    }
/*
    DatePickerDialog.OnDateSetListener dateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {


            Calendar c = Calendar.getInstance();
            c.set(Calendar.YEAR, year);
            c.set(Calendar.MONTH, month);
            c.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            years=c.get(Calendar.YEAR);
            months=c.get(Calendar.MONTH);
            days=c.get(Calendar.DAY_OF_MONTH);

            String currentFullDateString = DateFormat.getDateInstance(DateFormat.MEDIUM).format(c.getTime());

            adapter.setDateSet(currentFullDateString);

        }
    };

    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DATE_DIALOG_ID:

                return new DatePickerDialog(getActivity().getApplicationContext(),
                        dateListener,years,months,days);

        }
        return null;

    }*/




}
