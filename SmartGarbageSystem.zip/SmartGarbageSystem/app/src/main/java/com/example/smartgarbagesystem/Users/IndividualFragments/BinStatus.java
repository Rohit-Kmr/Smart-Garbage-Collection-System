package com.example.smartgarbagesystem.Users.IndividualFragments;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.TextView;

import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class BinStatus extends Fragment {
    private onFragmentSelected listener;     //reference of interface onFragmentSelected Listener

    String status;
    RadioButton radioButton = null;
    User user = null;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.individual_bin_status_fragment, container, false);


        //standard way to call the button implementation from fragments.
       /* TextView textView =view.findViewById(R.id.textIndividualLogout);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onTextSelected();
            }
        });*/

        //status="error";
        user = new User(getActivity().getApplicationContext());
        getBinStatus(view);


        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        // to check whether  the instance of interface is attach to the class or not.
        if (context instanceof onFragmentSelected) {
            listener = (onFragmentSelected) context;
        } else {
            throw new ClassCastException(context.toString() + "must implement listener");
        }

    }

    public interface onFragmentSelected {
        //funciton to be implemented.
        public void onTextSelected();
    }

    public void getBinStatus(final View view) {
       final DatabaseReference ref = FirebaseDatabase.getInstance().getReference("user").child("Individual").child(user.getId());
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                status = dataSnapshot.child("bin status").getValue(String.class);
                setBinStatus(view);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void setBinStatus(View view) {
        System.out.println("status:"+status);
        if (status.equals("green")) {
            radioButton = view.findViewById(R.id.greenRadioButton);
            radioButton.setChecked(true);
            radioButton.setClickable(false);
            radioButton = view.findViewById(R.id.orangeRadioButton);
            radioButton.setClickable(false);
            radioButton = view.findViewById(R.id.redRadioButton);
            radioButton.setClickable(false);

        } else if (status.equals("orange")) {
            radioButton = view.findViewById(R.id.orangeRadioButton);
            radioButton.setChecked(true);
            radioButton.setClickable(false);
            radioButton = view.findViewById(R.id.greenRadioButton);
            radioButton.setClickable(false);
            radioButton = view.findViewById(R.id.redRadioButton);
            radioButton.setClickable(false);
        } else if (status.equals("red")) {
            radioButton = view.findViewById(R.id.redRadioButton);
            radioButton.setChecked(true);
            radioButton.setClickable(false);
            radioButton = view.findViewById(R.id.orangeRadioButton);
            radioButton.setClickable(false);
            radioButton = view.findViewById(R.id.greenRadioButton);
            radioButton.setClickable(false);
        } else {
            radioButton = view.findViewById(R.id.redRadioButton);
            radioButton.setClickable(false);

            radioButton = view.findViewById(R.id.orangeRadioButton);
            radioButton.setClickable(false);
            radioButton = view.findViewById(R.id.greenRadioButton);
            radioButton.setClickable(false);
            TextView textView1 = view.findViewById(R.id.textError);
            textView1.setText("Hardware Error!!!!");
        }
    }
}