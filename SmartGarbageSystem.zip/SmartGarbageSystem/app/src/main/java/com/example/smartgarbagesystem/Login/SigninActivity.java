package com.example.smartgarbagesystem.Login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smartgarbagesystem.MainActivity;
import com.example.smartgarbagesystem.R;
import com.example.smartgarbagesystem.Users.CollectorAgent;
import com.example.smartgarbagesystem.Users.IndividualUser;
import com.example.smartgarbagesystem.Users.RecyclingAgent;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SigninActivity extends AppCompatActivity {
    TextView textView=null;
    EditText editText1=null;
    EditText editText2=null;
    Button button=null;
    String name,pass;
    User user=null;
    AutoCompleteTextView autoCompleteTextView;
    String[] UserTypeList = new String[] {"Individual","Collector Agent","Recycling Agent"};
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin);

         textView=findViewById(R.id.textSignIn);
         textView.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent intent=new Intent(getApplicationContext(),SignupActivity.class);
                 startActivity(intent);
             }
         });
         user=new User(getApplicationContext());

         editText1=findViewById(R.id.userEdit2);


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.select_dialog_item, UserTypeList);
        autoCompleteTextView =findViewById(R.id.autoCompleteTextview2);
        autoCompleteTextView.setThreshold(1);
        autoCompleteTextView.setAdapter(adapter);

         editText2=findViewById(R.id.passwordEdit2);

         button=findViewById(R.id.signinButton);
         button.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String username=editText1.getText().toString();
                 String password=editText2.getText().toString();

                 if(username.equals("")||password.equals(""))
                 {
                     Toast.makeText(SigninActivity.this,"Invalid Login",Toast.LENGTH_SHORT).show();
                 }
                 else
                 {
                     System.out.println("enter2");
                     checkUser(username,password);


                 }
             }
         });


    }
    public void checkUser(final String username, String password)
    {
        name=username;
        pass=password;
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("user").child(autoCompleteTextView.getText().toString());
        ref.orderByChild("username").equalTo(name).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                System.out.println("enter 3");
                int flag=0;
                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {

                    if (name.equals(userSnapshot.child("username").getValue(String.class))
                    && pass.equals(userSnapshot.child("password").getValue(String.class))) {

                        flag=1;
                        String userType=autoCompleteTextView.getText().toString();
                        Toast.makeText(SigninActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();

                        User user=new User(SigninActivity.this);
                        user.setUsername(name);
                        user.setPassword(pass);
                        user.setUserType(userType);
                        user.setId(userSnapshot.getKey());
                        System.out.println("before signin in:"+userSnapshot.getKey());
                        if(userSnapshot.child("address").exists())
                            user.setAddress(userSnapshot.child("address").getValue(String.class));
                        //else
                          //  user.setAddress("");

                        if(userSnapshot.child("location").exists())
                            user.setLocation(userSnapshot.child("location").getValue(String.class));

                        if(userType.equals("Individual"))
                            startActivity(new Intent(SigninActivity.this, IndividualUser.class));
                        else
                        if(userType.equals("Collector Agent"))
                            startActivity(new Intent(SigninActivity.this, CollectorAgent.class));
                        else
                            startActivity(new Intent(SigninActivity.this, RecyclingAgent.class));



                        break;
                    }
                }

                if(flag==0)
                {
                    Toast.makeText(SigninActivity.this,"Invalid Login",Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "some error has occurred!!!", Toast.LENGTH_SHORT).show();
            }


        });

    }

}
