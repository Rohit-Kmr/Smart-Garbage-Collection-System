package com.example.smartgarbagesystem.Users.RecyclerFragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.R;
import com.example.smartgarbagesystem.Users.OtherFragments.MapFragmentActivity;
import com.google.android.gms.maps.GoogleMap;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Profile extends Fragment {
    private GoogleMap gMap=null;
    User user=null;
    Context context=null;
    EditText editText1=null,editText2=null,editText3=null,editText4=null,editText5=null;
    ImageView imageView=null;
    Button button=null;
    DatabaseReference databaseReference=null;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.recycler_profile_fragment,container,false);
        context=getActivity().getApplicationContext();
        user=new User(context);

        databaseReference = FirebaseDatabase.getInstance().getReference("user");
        editText1=view.findViewById(R.id.textRecyclerFirstName);
        if(!user.getUsername().isEmpty())
            editText1.setText(user.getUsername());
        editText1.setEnabled(false);

        editText3=view.findViewById(R.id.textRecyclerLastName);
        editText3.setText("");
        editText3.setEnabled(false);

        editText2=view.findViewById(R.id.textRecyclerEmail);
        if(!user.getEmail().isEmpty())
            editText2.setText(user.getEmail());
        editText2.setEnabled(false);


        editText4=view.findViewById(R.id.textRecyclerMobile);
        if(!user.getPhone().isEmpty())
            editText4.setText(user.getPhone());
        editText4.setEnabled(false);

        editText5=view.findViewById(R.id.textRecyclerAddress);
        if(!user.getAddress().isEmpty())
            editText5.setText(user.getAddress());
        editText5.setEnabled(true);
        editText5.setFocusable( true);
        editText5.setKeyListener( null );


        //make the edit text editable onClick of edit button.
        imageView=view.findViewById(R.id.editButtonRecyclerFirstName);
        imageView.setClickable(true);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setEnabled(true);
            }
        });

        imageView=view.findViewById(R.id.editButtonRecyclerLastName);
        imageView.setClickable(true);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText3.setEnabled(true);
            }
        });

        imageView=view.findViewById(R.id.editButtonRecyclerEmail);
        imageView.setClickable(true);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText2.setEnabled(true);
            }
        });

        imageView=view.findViewById(R.id.editButtonRecyclerMobile);
        imageView.setClickable(true);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText4.setEnabled(true);
            }
        });

        imageView=view.findViewById(R.id.editButtonRecyclerAddress);
        imageView.setClickable(true);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                System.out.println("enter2");
                Intent i = new Intent(getActivity().getApplicationContext(), MapFragmentActivity.class);
                startActivityForResult(i,2);

            }
        });


        button=view.findViewById(R.id.buttonRecyclerDone);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveChanges();
            }
        });


        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==2)
        {
            if(resultCode== Activity.RESULT_OK)
            {
                editText5.setText(data.getStringExtra("address"));

                //editText5.setCursorVisible(true);
            }
        }
    }

    public void saveChanges()
    {

        user.setUsername(editText1.getText().toString()+" "+editText3.getText().toString());
        editText1.setEnabled(false);

        user.setEmail(editText2.getText().toString());
        editText3.setEnabled(false);

        user.setPhone(editText4.getText().toString());
        editText4.setEnabled(false);

        user.setAddress(editText5.getText().toString());


        databaseReference.child(user.getUserType()).child(user.getId()).child("address").setValue(user.getAddress());
        System.out.println("location:"+user.getLocation());
        databaseReference.child(user.getUserType()).child(user.getId()).child("location").setValue(user.getLocation());

        databaseReference.child(user.getUserType()).child(user.getId()).child("phone").setValue(user.getPhone());



        Toast.makeText(getActivity().getApplicationContext(),"Changes done successfully",Toast.LENGTH_SHORT).show();
    }
}


