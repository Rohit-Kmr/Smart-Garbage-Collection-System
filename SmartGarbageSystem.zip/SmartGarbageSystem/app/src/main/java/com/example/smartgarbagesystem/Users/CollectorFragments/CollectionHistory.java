package com.example.smartgarbagesystem.Users.CollectorFragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.OtherClasses.CollectionHistoryAdapter;
import com.example.smartgarbagesystem.OtherClasses.CollectionHistorySetGetClass;
import com.example.smartgarbagesystem.OtherClasses.HistoryListAdapter;
import com.example.smartgarbagesystem.OtherClasses.IndividualHistorySetGetClass;
import com.example.smartgarbagesystem.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CollectionHistory extends Fragment {
    ListView listView=null;
    User user=null;
    static  int i;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.collector_collection_history_fragment,container,false);
        listView=view.findViewById(R.id.listview5);
        user=new User(getActivity().getApplicationContext());
        setDataInList();
        return view;
    }

    public  void setDataInList()
    { i=0;
        System.out.println("enter4");
        System.out.println(user.getId());
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("user").child("Collector Agent");
        ref.orderByChild(user.getId()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(i<1)
                {
                    System.out.println("enter2");
                    setData(dataSnapshot);
                    i++;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    public  void setData(DataSnapshot dataSnapshot)
    {
        //System.out.println("enter");
        int j=0;
        //String collectiondate="";
        ArrayList<CollectionHistorySetGetClass> arrayList=new ArrayList<>();
       // for(DataSnapshot dataSnapshot1:dataSnapshot.getChildren())
        //{

        System.out.println("j:"+j);
        System.out.println(dataSnapshot.getValue());
            while(dataSnapshot.child(user.getId()).child("CollectionRequest").child(String.valueOf(j)).exists())
            {
                System.out.println("j:"+j);

                String value=dataSnapshot.child(user.getId()).child("CollectionRequest").child(String.valueOf(j)).getValue(String.class);
                String name=value.split("&&")[0];
                String date=value.split("&&")[2];
                arrayList.add(new CollectionHistorySetGetClass(name,date,"Regular"));
                j++;
            }




        CollectionHistoryAdapter adapter=new CollectionHistoryAdapter(getActivity().getApplicationContext(),R.layout.collector_collection_history_adapter,arrayList);
        listView.setAdapter(adapter);
    }


}
