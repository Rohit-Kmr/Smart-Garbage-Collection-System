package com.example.smartgarbagesystem.Users.IndividualFragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;


public class AddNewRequest extends Fragment {

    EditText editText1=null,editText2=null,editText3=null;
    DatabaseReference ref=null;
    User user=null;
    Button button=null;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.individual_add_new_request, container, false);

            ref= FirebaseDatabase.getInstance().getReference("user");
            user= new User(getActivity().getApplicationContext());
        editText1=view.findViewById(R.id.editItem);
        editText2=view.findViewById(R.id.editItemName);
        editText3=view.findViewById(R.id.editItemDescription);

        button=view.findViewById(R.id.buttonSumbitRequest);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("enter1");
                String value1=editText2.getText().toString();
                String value2=editText1.getText().toString();
                System.out.println("value2:"+editText2.getText().toString());
                System.out.println("value1:"+editText1.getText().toString());
                if(editText2==null||editText1==null||value1.trim().equals("")||value2.trim().equals("")||editText2.getText().toString().trim().equals("")||editText1.getText().toString().trim().equals(""))
                    Toast.makeText(getActivity().getApplicationContext(),"pls, fill all mandatory details!!!",Toast.LENGTH_LONG);
                else
                 if(user.getAddress()!=null&&!user.getAddress().trim().equals(""))
                {
                    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
                    String currentDateandTime = sdf.format(new Date());

                    String request_id= String.valueOf(new Random().nextInt(10000000)+1000000);
                    ref.child("Individual").child(user.getId()).child("New Request").child("Id").setValue(request_id);
                    ref.child("Individual").child(user.getId()).child("New Request").child("Item").setValue(editText1.getText().toString());
                    ref.child("Individual").child(user.getId()).child("New Request").child("Item Name").setValue(editText2.getText().toString());
                    ref.child("Individual").child(user.getId()).child("New Request").child("Item Description").setValue(editText3.getText().toString());
                    ref.child("Individual").child(user.getId()).child("New Request").child("collection date").setValue(" ");
                    ref.child("Individual").child(user.getId()).child("New Request").child("Notification").setValue("on");
                    ref.child("Individual").child(user.getId()).child("New Request").child("Request date").setValue(currentDateandTime);
                    ref.child("Individual").child(user.getId()).child("New Request").child("Collector").setValue("");
                    Toast.makeText(getActivity().getApplicationContext(),"Sent and Your Request Id:"+request_id,Toast.LENGTH_LONG).show();
                }
                 else
                     Toast.makeText(getActivity().getApplicationContext(),"Set the Address first",Toast.LENGTH_LONG).show();


            }
        });


    return view;
    }
}
