package com.example.smartgarbagesystem.Users.RecyclerFragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.smartgarbagesystem.R;

public class RecycleItemList extends Fragment {
    private onFragmentSelected listener;     //reference of interface onFragmentSelected Listener
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.recycler_item_fragment,container,false);

        //standard way to call the button implementation from fragments.
        TextView textView =view.findViewById(R.id.textRecyclerLogout);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onTextSelected();
            }
        });
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        // to check whether  the instance of interface is attach to the class or not.
        if(context instanceof onFragmentSelected)
        {
            listener=(onFragmentSelected) context;
        }else
        {
            throw new ClassCastException(context.toString()+"must implement listener");
        }

    }
    public interface onFragmentSelected {
        //funciton to be implemented.
        public void onTextSelected();
    }
}
