package com.example.smartgarbagesystem.OtherClasses;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.smartgarbagesystem.R;

import java.util.List;

public class RecylerHistoryAdapter extends ArrayAdapter<RecyclerHistorySetGetClass> {
    private Context context=null;
    int mResource;

    public RecylerHistoryAdapter(Context context, int resource, List<RecyclerHistorySetGetClass> objects) {
        super(context, resource, objects);
        this.context = context;
        mResource=resource;

    }



    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater=LayoutInflater.from(context);
        convertView=inflater.inflate(mResource,parent,false);

        String userType=getItem(position).getUserType();
        String username=getItem(position).getUsername();
        String phone=getItem(position).getPhone();

        //Create the history object with information
        RecylingAgentListSetGetClass history=new RecylingAgentListSetGetClass(userType,username,phone);



        TextView textuserType= convertView.findViewById(R.id.textUserType2);
        TextView textreportdate=convertView.findViewById(R.id.textUsername);
        TextView textcollectdate=convertView.findViewById(R.id.textPhone);

        textuserType.setText(userType);
        textreportdate.setText(username);
        textcollectdate.setText(phone);

        return convertView;

    }


}

