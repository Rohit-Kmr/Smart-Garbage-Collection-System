package com.example.smartgarbagesystem.Users.IndividualFragments;

import android.app.Dialog;
import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.R;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class CollectionDate extends Fragment {
    private onFragmentButtonSelected listener;     //reference of interface onFragmentSelected Listener
    Button button1=null,button2=null,button3=null;
    User user;
    HashMap<String,String> hm=null;
    private DatabaseReference mDatabase=null;
    EditText editText1,editText2,editText3;
    static int i,j; //to control loop.so that loop doesn't overflow.
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.individual_collect_date_fragment,container,false);
        //standard way to call the button implementation from fragments.



        editText1=view.findViewById(R.id.Text1);
        editText1.setEnabled(false);

        editText2=view.findViewById(R.id.Text2);
        editText2.setEnabled(false);
        editText3=view.findViewById(R.id.Text3);
        editText3.setEnabled(false);

        user=new User(getActivity().getApplicationContext());
        mDatabase = FirebaseDatabase.getInstance().getReference();

        view.findViewById(R.id.button1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!user.getAddress().trim().equals("")&&user.getAddress()!=null)
                listener.onButtonSelected(R.id.Text1);
                else
                    Toast.makeText(getActivity().getApplicationContext(),"pls set the address first!!!",Toast.LENGTH_LONG).show();
            }
        });

        view.findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!user.getAddress().trim().equals("")&&user.getAddress()!=null)
                listener.onButtonSelected(R.id.Text2);
                else
                Toast.makeText(getActivity().getApplicationContext(),"pls set the address first!!!",Toast.LENGTH_LONG).show();
            }
        });

        view.findViewById(R.id.button3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!user.getAddress().trim().equals("")&&user.getAddress()!=null)
                listener.onButtonSelected(R.id.Text3);
                   else
                Toast.makeText(getActivity().getApplicationContext(),"pls set the address first!!!",Toast.LENGTH_LONG).show();
            }
        });

        view.findViewById(R.id.submitButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!user.getAddress().trim().equals("")&&user.getAddress()!=null){
                    listener.onSubmitButtonSelected(getContext());
                    checkCollectionDateExist();

                }
                else
                    Toast.makeText(getActivity().getApplicationContext(),"pls set the address first!!!",Toast.LENGTH_LONG).show();

            }
        });


        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        // to check whether  the instance of interface is attach to the class or not.
        if(context instanceof BinStatus.onFragmentSelected)
        {
            listener=(onFragmentButtonSelected) context;
        }else
        {
            throw new ClassCastException(context.toString()+"must implement listener");
        }

    }

    public interface onFragmentButtonSelected {
        //funciton to be implemented.
        public void onButtonSelected(int i);

        public void onSubmitButtonSelected(Context context);
    }

    public void onSelectNearestCollectorAgent()
    {
        System.out.println("nearest node");

        i=0;//to control loop.so that it doesnot overflow.
        System.out.println("i="+i);
        hm=new HashMap<String,String>();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("user").child("Collector Agent");
        ref.orderByChild("location").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(i<1) {
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        System.out.println("enter1");
                        if (userSnapshot.child("location").exists()) {
                            System.out.println("enter2");

                            hm.put(userSnapshot.getKey(), userSnapshot.child("location").getValue(String.class));
                            System.out.println("key:"+userSnapshot.getKey());
                        }

                    }
                    System.out.println("enter3");
                    findMinDistcollector(hm,dataSnapshot);
                    i++;
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void findMinDistcollector(HashMap<String,String> hashMap,DataSnapshot dataSnapshot)
    {
        float minDist=1000000;
        String value="";
        String key="";
        LatLng latLng1=findLatLng(user.getLocation());
        for(Map.Entry m:hashMap.entrySet()){
            LatLng latLng2=findLatLng(m.getValue().toString());
            float[] result=new float[1];
            Location.distanceBetween(latLng1.latitude,latLng1.longitude,latLng2.latitude,latLng2.longitude,result);
            if(minDist>result[0])
            {
                minDist=result[0];
                value=m.getValue().toString();
            }
        }

        for(Map.Entry m:hashMap.entrySet()){
            if(value==m.getValue().toString())
              key=m.getKey().toString();
        }

       //mDatabase.child("user").child("Collector Agent").child(key).child("CollectionRequest").setValue(null);
        HashMap<String,String> hashMap1=getAllStoreData(dataSnapshot,key);
        int i=hashMap1.size();
        hashMap1.put(Integer.toString(i),user.getUsername()+"&&"+user.getLocation()+"&&"+editText1.getText().toString());
        System.out.println(hashMap1);

        dataSnapshot.child(key).child("CollectionRequest").getRef().removeValue();
        mDatabase.child("user").child("Collector Agent").child(key).child("CollectionRequest").setValue(hashMap1);

    }

    public LatLng findLatLng(String value)
    {
        String[] location;
        location=value.split(" ");
        LatLng latLng=new LatLng(Double.valueOf(location[0]),Double.valueOf(location[1]));
        return latLng;
    }
    public HashMap<String,String> getAllStoreData(DataSnapshot dataSnapshot,String key)
    {
        HashMap<String,String> hashMap=new HashMap<>();
        int j=0;
        System.out.println("enter5");
        while(dataSnapshot.child(key).child("CollectionRequest").child(Integer.toString(j)).exists())
        {
            System.out.println("enter6");
            System.out.println("i:"+j);
          hashMap.put(Integer.toString(j),dataSnapshot.child(key).child("CollectionRequest").child(Integer.toString(j)).getValue(String.class));
            j++;
        }
        dataSnapshot.child(key).child("CollectionRequest").getRef().removeValue();
        return hashMap;
    }

    public void checkCollectionDateExist()
    {
        j=0; //to control loop.so that it doesnot overflow.
        System.out.println("j:"+j);
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("user");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(j<1) {
                    if (!dataSnapshot.child(user.getUserType()).child(user.getId()).child("collection date").child("0").exists())
                    {
                        System.out.println("enter the loop");
                        onSelectNearestCollectorAgent();
                    }


                    j++;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}
