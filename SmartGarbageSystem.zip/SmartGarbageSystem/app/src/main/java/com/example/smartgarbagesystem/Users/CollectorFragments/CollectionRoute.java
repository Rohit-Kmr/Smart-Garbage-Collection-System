package com.example.smartgarbagesystem.Users.CollectorFragments;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.Map.LocatePath;
import com.example.smartgarbagesystem.OtherClasses.CollectionRequestSetGetClass;
import com.example.smartgarbagesystem.OtherClasses.CollectionRequestionAdapter;
import com.example.smartgarbagesystem.R;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class CollectionRoute extends Fragment {
    ListView mlistView=null;
    DatabaseReference ref=null;
    User user=null;
    HashMap<String,String> hashMap;
    static int i;
    Button button=null;
    private onFragmentSelected listener;     //reference of interface onFragmentSelected Listener
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.collector_route_fragment,container,false);

        //standard way to call the button implementation from fragments.
        ref=FirebaseDatabase.getInstance().getReference();
        mlistView=view.findViewById(R.id.listview2);
        user=new User(getActivity().getApplicationContext());
        setDataInList();
        button=view.findViewById(R.id.buttonDrawRoute);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity().getApplicationContext(), LocatePath.class);
                intent.putExtra("location",getLatlng()); // getText() SHOULD NOT be static!!!
                startActivity(intent);

            }
        });
        return view;
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        // to check whether  the instance of interface is attach to the class or not.
        if(context instanceof onFragmentSelected)
        {
            listener=(onFragmentSelected) context;
        }else
        {
            throw new ClassCastException(context.toString()+"must implement listener");
        }

    }
    public interface onFragmentSelected {
        //funciton to be implemented.
        public void onTextSelected();
    }

    public void setDataInList()
    {
        hashMap=new HashMap<>();
        i=0;
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("user");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (i < 1) {


                    int j = 0;
                    while (dataSnapshot.child(user.getUserType()).child(user.getId()).child("CollectionRequest").child(Integer.toString(j)).exists()) {
                        { hashMap.put(Integer.toString(j), dataSnapshot.child(user.getUserType()).child(user.getId()).child("CollectionRequest").child(Integer.toString(j)).getValue(String.class));
                        j++;}
                    }

                    setData(hashMap);

                    //hashMap=dataSnapshot.child(user.getUsername()).child(user.getId()).child("CollectionRequest").getValue(String.class);
                }
                i++;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }



         });

    }

    public  void setData(HashMap<String,String> hashMap)
    {
        int size=hashMap.size();
        System.out.println("size:"+size);
        ArrayList<CollectionRequestSetGetClass> arrayListRequest=new ArrayList<>();

        for(int i=0;i<size;i++)
        {
            String request=hashMap.get(Integer.toString(i));
            System.out.println("request:"+request);
            String[] value=request.split("&&");
            System.out.println("val[0]"+value[0]);
            System.out.println("val[1]"+value[1]);
            System.out.println("val[2]"+value[2]);
            String address=getAddress(new LatLng(Float.valueOf(value[1].split(" ")[0]),Float.valueOf(value[1].split(" ")[1])));
            CollectionRequestSetGetClass collectRequest=new CollectionRequestSetGetClass(value[0],address,value[2]);
            arrayListRequest.add(collectRequest);
        }
        CollectionRequestionAdapter adapter=new CollectionRequestionAdapter(getActivity().getApplicationContext(),R.layout.collector_route_list_adapter,arrayListRequest);
        mlistView.setAdapter(adapter);
    }

    public String[] getLatlng()
    {
        int k=0;
        int size=hashMap.size();
        String[] array=new String[size+1];

        for(k=0;k<size;k++)
        {
            String request=hashMap.get(Integer.toString(k));
            //String[] value=request.split(" ");
            array[k]=request;
        }
        array[k]="MyLocation&&"+user.getLocation();
        return array;
    }



    public String getAddress(LatLng latLng)
    {
        Geocoder geocoder = new Geocoder(getActivity().getApplicationContext(), Locale.getDefault());
        List<Address> addresses=null;
        try {
            addresses = geocoder.getFromLocation(latLng.latitude,latLng.longitude, 1); //1 num of possible location returned                        }

        }catch (Exception e)
        {
            System.out.println("Error while getting address of marker");
        }

        String address = addresses.get(0).getAddressLine(0); //0 to obtain first possible address
        String city = addresses.get(0).getLocality();
        String state = addresses.get(0).getAdminArea();
        String country = addresses.get(0).getCountryName();
        String postalCode = addresses.get(0).getPostalCode();


        //create your custom title
        String title = address+"-"+city+"-"+state;
        return title;

    }

}