package com.example.smartgarbagesystem.OtherClasses;

import android.app.Activity;
import android.app.Application;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
//import android.support.v4.app.FragmentActivity;
//import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smartgarbagesystem.R;
import com.example.smartgarbagesystem.Users.CollectorAgent;
import com.example.smartgarbagesystem.Users.OtherFragments.DatePickerFragment;
import com.example.smartgarbagesystem.Users.OtherFragments.DatePickerFragmentActivity;
import com.example.smartgarbagesystem.Users.OtherFragments.MapFragmentActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;

public class CollectionExtraRequestAdapter extends ArrayAdapter<CollectionExtraRequestSetGetClass> {

    private Context context=null;
    int mResource;
    TextView textcollectionDate=null;
    static String collectdate;
    String dateSet="";
    static final int DATE_DIALOG_ID = 0;
    DatabaseReference ref=null;
    String username=null;
    String numOfItem=null;

    private ArrayList<CollectionExtraRequestSetGetClass> list = new ArrayList<>();
    //TextView textView=null;




    public CollectionExtraRequestAdapter(Context context, int resource, List<CollectionExtraRequestSetGetClass> objects) {
        super(context, resource, objects);
        this.context = context;
        mResource=resource;
        list=(ArrayList<CollectionExtraRequestSetGetClass>) objects;

    }



    @NonNull
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater=LayoutInflater.from(context);
        convertView=inflater.inflate(mResource,parent,false);

        username=getItem(position).getUsername();
        numOfItem=getItem(position).getRequestItem();
        String ItemName=getItem(position).getRequestItemName();
        String ItemDescription=getItem(position).getRequestItemDescription();



        //Create the history object with information
        //IndividualHistorySetGetClass history=new IndividualHistorySetGetClass(username,location,collectionDate);
        CollectionExtraRequestSetGetClass request =new CollectionExtraRequestSetGetClass(username,numOfItem,ItemName,ItemDescription," ");


        TextView textUsername= convertView.findViewById(R.id.textUsername);
        TextView textNumOfItem=convertView.findViewById(R.id.textNumberOfItem);
        TextView textItemName=convertView.findViewById(R.id.textItemName);
        TextView textItemDescription=convertView.findViewById(R.id.textItemDescription);
        textcollectionDate=convertView.findViewById(R.id.textCollectdate);
        //textView=convertView.findViewById(R.id.textCollectdate);


        System.out.println("name:"+username);
        Button button=convertView.findViewById(R.id.buttonSetDate);
        button.setTag(position);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username=list.get(position).getUsername();
                numOfItem=list.get(position).getRequestItem();
                list.remove(position);
                CollectionExtraRequestAdapter.this.notifyDataSetChanged();
                System.out.println("name inside listener:"+username);
                Intent intent=new Intent(getContext(), DatePickerFragmentActivity.class);
                intent.putExtra("id",username+" "+numOfItem);
                getContext().startActivity(intent);
                //  if(!textcollectionDate.getText().toString().equals("")&&textcollectionDate.getText().toString()!=null)
               // getDate(username,numOfItem,position);
                //textcollectionDate.setText(collectdate);
               // System.out.println("collect date:"+collectdate);


            }
        });
        String collectionDate=getItem(position).getCollectiondate();



       // String collectionDate=getItem(position).getCollectiondate();
        System.out.println("date:"+collectionDate);
        textcollectionDate.setText(collectionDate);
        textUsername.setText(username);
        textNumOfItem.setText(numOfItem);
        textItemName.setText(ItemName);
        textItemDescription.setText(ItemDescription);


              return convertView;

    }






    public void setDateSet(String dateSet) {
        this.dateSet = dateSet;
    }

    public static void setText(String date)
    {
        //collectdate=date;
        //System.out.println("static date:"+collectdate);
        //textcollectionDate.setText(date);


    }
/*
    public void getDate(final String username, final String numOfItem,final int poistion)
    {System.out.println("enter2");
       // final String date=textcollectionDate.getText().toString();
        ref= FirebaseDatabase.getInstance().getReference("user").child("Individual");
        ref.orderByKey().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot userDataSnapShot: dataSnapshot.getChildren())
                {

                       //System.out.println("enter, key:"+key);
                       //ref.child(key).child("New Request").child("collection date").setValue(date);
                    if(username.equals(userDataSnapShot.child("username").getValue(String.class)))
                        list.get(poistion).setCollectiondate(userDataSnapShot.child("New Request").child("collection date").getValue(String.class));
                    Toast.makeText(getContext(),"Selected date:"+list.get(poistion).getCollectiondate(),Toast.LENGTH_LONG).show();

                    //(userDataSnapShot.child("New Request").child("collection date").getValue(String.class));
                    //System.out.println("inside date:"+list.get(poistion).getCollectiondate());
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

*/
}
