package com.example.smartgarbagesystem.Users;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smartgarbagesystem.Login.SigninActivity;
import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.R;
import com.example.smartgarbagesystem.Users.IndividualFragments.AddNewRequest;
import com.example.smartgarbagesystem.Users.IndividualFragments.BinStatus;
import com.example.smartgarbagesystem.Users.IndividualFragments.CollectionDate;
import com.example.smartgarbagesystem.Users.IndividualFragments.History;
import com.example.smartgarbagesystem.Users.IndividualFragments.Profile;
import com.example.smartgarbagesystem.Users.OtherFragments.DatePickerFragment;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.example.smartgarbagesystem.NotficationApplication.CHANNEL_1_ID;

public class IndividualUser extends AppCompatActivity implements  NavigationView.OnNavigationItemSelectedListener,BinStatus.onFragmentSelected,CollectionDate.onFragmentButtonSelected
, DatePickerDialog.OnDateSetListener{
    DrawerLayout drawerLayout;                        //instance of drawer layout.
    ActionBarDrawerToggle actionBarDrawerToggle;      //action bar instance.
    Toolbar toolbar;                                  // toolbar instance.
    NavigationView navigationView;

    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    EditText editText=null;

    int Id=0,index=1,flag=0;
    ArrayList<String> dates=new ArrayList<String>();
    User user=null;
    DatabaseReference databaseReference=null;
    static int i;

    //for notification
    private NotificationManagerCompat notificationManager;
    private EditText editTextTitle;
    private EditText editTextMessage;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_individual_user);

        user=new User(IndividualUser.this);
        notificationManager = NotificationManagerCompat.from(this);
       //check notification
        checkNotification();

       // TextView textView=findViewById(R.id.welcomeUser);
        //textView.setText("Hello, "+user.getUsername());

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);





        System.out.println("userType"+user.getUserType());
        System.out.println("username:"+user.getUsername());
        System.out.println("Id"+user.getId());
        drawerLayout = findViewById(R.id.drawer);
        navigationView = findViewById(R.id.navigationView);
        navigationView.setNavigationItemSelectedListener(IndividualUser.this);         //to select an option of menu.


        // add all essential item to action bar.
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        actionBarDrawerToggle.syncState();


        //Load the default fragment to the main layout.
        fragmentManager = getSupportFragmentManager();           //instance of fragment.
        fragmentTransaction = fragmentManager.beginTransaction();  //to start some actions.
        fragmentTransaction.add(R.id.frame_layout, new BinStatus());  //add the fragment to the frame layout(content of layout).
        fragmentTransaction.commit();                                    //commit the changes.


    }

    //function of onNavigationViewListener interface.
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        drawerLayout.closeDrawer(GravityCompat.START);      //to close navigation view on click.
        if(menuItem.getItemId()==R.id.individualProfile)
        {//call the profile layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new Profile());
            fragmentTransaction.commit();
        }
        else
        if(menuItem.getItemId()==R.id.individualColDate)
        { //call the Collection data layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new CollectionDate());
            fragmentTransaction.commit();
        }
        else
        if(menuItem.getItemId()==R.id.individualHistory)
        { //call the History layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new History());
            fragmentTransaction.commit();
        }
        else
        if(menuItem.getItemId()==R.id.individualBinStatus)
        { //call the Bin status layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new BinStatus());
            fragmentTransaction.commit();
        }
        else
        if(menuItem.getItemId()==R.id.individualAboutUs)
        { //call the About us layout fragment.
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new AboutUs());
            fragmentTransaction.commit();
        }

        else
        if(menuItem.getItemId()==R.id.individualAddRequest)
        {
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, new AddNewRequest());
            fragmentTransaction.commit();
        }
        else
            if(menuItem.getItemId()==R.id.logout)
            {
                startActivity(new Intent(getApplicationContext(),SigninActivity.class));
                finish();
            }

        return true;

    }

    @Override
    public void onTextSelected() {
        startActivity(new Intent(getApplicationContext(), SigninActivity.class));
    }

    @Override
    public void onButtonSelected(int i) {
        Id=i;
        DialogFragment datePicker = new DatePickerFragment();
        datePicker.show(getSupportFragmentManager(), "date picker");

    }

    @Override
    public void onSubmitButtonSelected(Context context) {
        i=0;

        EditText editText1,editText2,editText3;
        editText1=findViewById(R.id.Text1);
        editText2=findViewById(R.id.Text2);
        editText3=findViewById(R.id.Text3);

        String date1=editText1.getText().toString();
        String date2=editText2.getText().toString();
        String date3=editText3.getText().toString();
        flag=0;

        //if(date1.trim().equals("")&&date2.trim().equals("")&&date3.trim().equals(""))
        //{
        //    Toast.makeText(getApplicationContext(),"At least Set One Date of Collection!!!",Toast.LENGTH_LONG).show();
        //}
        if(date1.trim().equals(""))
        {
            Toast.makeText(getApplicationContext(),"1st preference of must be filed!!!",Toast.LENGTH_LONG).show();
        }
        else
        if(date2.trim().equals("")&&(!date3.trim().equals("")))
        {
            Toast.makeText(getApplicationContext(),"2nd preference must be filled before 3rd!!!",Toast.LENGTH_LONG).show();
        }
        else
        if((date1.equals(date2)&&!date1.trim().equals(""))||(date1.equals(date3)&&!date3.trim().equals(""))||(date2.equals(date3)&&!date2.trim().equals("")))
        {
            Toast.makeText(getApplicationContext(),"Two dates are same!!!",Toast.LENGTH_LONG).show();
        }
        else {
            new AlertDialog.Builder(context)
                    .setTitle("Save Date")
                    .setMessage("Are you sure you want to save the changes?")

                    // Specifying a listener allows you to take an action before dismissing the dialog.
                    // The dialog is automatically dismissed when a dialog button is clicked.
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                            databaseReference = FirebaseDatabase.getInstance().getReference("user");


                                databaseReference.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        System.out.println("userID:"+ user.getId());
                                        if(dataSnapshot.child(user.getUserType()).child(user.getId()).child("collection date").exists())
                                            System.out.println("collectionDate Exist!!!!");
                                        if ((!dataSnapshot.child(user.getUserType()).child(user.getId()).child("collection date").exists())&&i==0) {
                                            Toast.makeText(getApplicationContext(), "Date is set successfully!!!", Toast.LENGTH_LONG).show();

                                            SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
                                            String currentDateandTime = sdf.format(new Date());
                                            dates.add(0,currentDateandTime);
                                            databaseReference.child(user.getUserType()).child(user.getId()).child("collection date").setValue(dates);
                                           // databaseReference.child(user.getUserType()).child(user.getId()).child("address").setValue(user.getAddress());
                                            //System.out.println("location:"+user.getLocation());
                                            //databaseReference.child(user.getUserType()).child(user.getId()).child("location").setValue(user.getLocation());
                                            flag=1; //to set that collection date is now filled.
                                            i++;

                                        } else if(flag!=1)  //flag to just make else condition run only one time otherwise it run continuously.
                                            {

                                                Toast.makeText(getApplicationContext(), "Date is already set!!!", Toast.LENGTH_LONG).show();

                                            }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }

                                });
                            }

                    })

                    // A null listener allows the button to dismiss the dialog and take no further action.
                    .setNegativeButton(android.R.string.no, null)
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();
        }

        if(flag==1)
        databaseReference.child("user").child(user.getId()).child("collection date").setValue(dates);
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        c.set(Calendar.DAY_OF_MONTH, dayOfMonth);

        String currentFullDateString = DateFormat.getDateInstance(DateFormat.MEDIUM).format(c.getTime());

        editText=findViewById(Id);
        editText.setText(currentFullDateString);// to set current date in edit field.

        if(!currentFullDateString.trim().equals(""))
        dates.add(currentFullDateString);

    }



    public void checkNotification()
    {
        final DatabaseReference ref=FirebaseDatabase.getInstance().getReference("user").child("Individual").child(user.getId());

            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if(dataSnapshot.child("New Request").exists())
                    {
                        String date=dataSnapshot.child("New Request").child("collection date").getValue(String.class);
                        String notificationStatus=dataSnapshot.child("New Request").child("Notification").getValue(String.class);
                        if(date!=null&&!date.trim().equals("")&&notificationStatus.equals("on"))
                        {

                            ref.child("New Request").child("Notification").setValue("off");
                            sendNotifcation(date);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }




    public void sendNotifcation(String date)
    {
        String title = "Item Collection date";
        System.out.println("enter Notification");
        String message = date;
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_1_ID)
                .setSmallIcon(R.drawable.ic_alert)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .build();
        notificationManager.notify(2, notification);
    }
}


