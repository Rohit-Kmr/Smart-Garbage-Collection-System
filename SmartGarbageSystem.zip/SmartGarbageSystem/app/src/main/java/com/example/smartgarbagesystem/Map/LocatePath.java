package com.example.smartgarbagesystem.Map;

import android.app.DownloadManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;

public class LocatePath extends AppCompatActivity implements OnMapReadyCallback , TaskLoadedCallback {

    private GoogleMap aMap;
    Polyline currentPolyline;
    Button button=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locatepath);
        button=findViewById(R.id.submit);
        System.out.println("Enter the activity");
        SupportMapFragment mapFragment=(SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.map_fragment);
        try {
            mapFragment.getMapAsync(this);
        }
        catch (Exception e)
        {
            System.out.println("null pointer exception");
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }


    private List<String> getDirectionsUrl(ArrayList<LatLng> markerPoints,String directionMode) {
        List<String> mUrls = new ArrayList<>();
        if (markerPoints.size() > 1) {
            String str_origin = markerPoints.get(0).latitude + "," + markerPoints.get(0).longitude;
            String str_dest = markerPoints.get(1).latitude + "," + markerPoints.get(1).longitude;

            //String sensor = "sensor=false";
            String mode= "mode="+directionMode;
            String key="key=AIzaSyD7rY0o95RVQuakXU2VZ2JssP2W9_QnOkw";
            String parameters = "origin=" + str_origin + "&destination=" + str_dest +"&" +mode+"&"+key;//+ "&" + sensor;
            String output = "json";
            String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;

            mUrls.add(url);
            for (int i = 2; i < markerPoints.size(); i++)//loop starts from 2 because 0 and 1 are already printed
            {
                str_origin = str_dest;
                str_dest = markerPoints.get(i).latitude + "," + markerPoints.get(i).longitude;
                parameters = "origin=" + str_origin + "&destination=" + str_dest + "&" + mode+"&"+key;//+"&"+sensor
                url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;
                mUrls.add(url);
            }
        }

        return mUrls;
    }

    @Override
    public void onMapReady(GoogleMap googleMap)
    {
        aMap=googleMap;


        //array list of latitude and longitude
        ArrayList<LatLng> latlngs = new ArrayList<>();



        String[] passedArg = getIntent().getExtras().getStringArray("location");
        int size=passedArg.length;
        //System.out.println("size1:"+size);

        for(int i=0;i<size;i++)
        {
            float latitude=Float.valueOf((passedArg[i].split( "&&"))[1].split(" ")[0]);
            System.out.println(Float.valueOf((passedArg[i].split( "&&"))[1].split(" ")[0]));
            float longtiude=Float.valueOf((passedArg[i].split( "&&"))[1].split(" ")[1]);
            System.out.println(Float.valueOf((passedArg[i].split( "&&"))[1].split(" ")[1]));
            latlngs.add(new LatLng(latitude,longtiude));
        }



        for(int i=0;i<latlngs.size();i++)
        {

                String userName=passedArg[i].split( "&&")[0];
                System.out.println("username:"+userName);

            Marker marker=aMap.addMarker(new MarkerOptions().position(latlngs.get(i)).title(userName));
            aMap.animateCamera(CameraUpdateFactory.newLatLngZoom(
                    latlngs.get(latlngs.size()-1), 15.0f));
            marker.showInfoWindow();
        }


        // aMap.addMarker(new MarkerOptions().position(sydney).title("Marker in sydney"));
        //aMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        List<String> urls = getDirectionsUrl(latlngs,"driving");
        if (urls.size() > 1) {
            for (int i = 0; i < urls.size(); i++) {
                String url = urls.get(i);
                new FetchURL(LocatePath.this).execute(url,"driving");
            }
        }

    }


    @Override
    public void onTaskDone(Object... values)
    {
        if(currentPolyline != null)
            currentPolyline.remove();

         currentPolyline = aMap.addPolyline((PolylineOptions) values[0]);


    }

}
