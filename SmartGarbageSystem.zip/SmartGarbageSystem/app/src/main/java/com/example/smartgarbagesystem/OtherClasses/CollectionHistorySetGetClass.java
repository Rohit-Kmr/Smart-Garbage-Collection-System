package com.example.smartgarbagesystem.OtherClasses;

public class CollectionHistorySetGetClass {
    private String username;
    private String collectionDate;
    private String GarbageType;

    public CollectionHistorySetGetClass(String username, String collectionDate, String garbageType) {
        this.username = username;
        this.collectionDate = collectionDate;
        GarbageType = garbageType;
    }

    public String getUsername() {
        return username;
    }

    public String getGarbageType() {
        return GarbageType;
    }

    public void setGarbageType(String garbageType) {
        GarbageType = garbageType;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCollectionDate() {
        return collectionDate;
    }

    public void setCollectionDate(String collectionDate) {
        this.collectionDate = collectionDate;
    }
}
