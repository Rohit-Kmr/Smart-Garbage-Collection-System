package com.example.smartgarbagesystem.Users.OtherFragments;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.smartgarbagesystem.Login.User;
import com.example.smartgarbagesystem.MainActivity;
import com.example.smartgarbagesystem.Map.TaskLoadedCallback;
import com.example.smartgarbagesystem.R;
import com.example.smartgarbagesystem.Users.IndividualFragments.Profile;
import com.example.smartgarbagesystem.Users.IndividualUser;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;
import java.util.Locale;

public class MapFragmentActivity extends AppCompatActivity implements OnMapReadyCallback,GoogleMap.OnMarkerDragListener,
GoogleMap.OnMapLongClickListener{
    GoogleMap map = null;
    LocationManager lm = null;
    Marker currentmarker=null;
    User user=null;

    Intent intent=null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locatepath);

        //initialize intent
        intent=new Intent();



        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map_fragment);
        try {
            mapFragment.getMapAsync(this);
        } catch (Exception e) {
            System.out.println("null pointer exception");
        }

        System.out.println("Exit onMapReady!!!!");
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);



        findViewById(R.id.submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(Activity.RESULT_OK, intent);
                finish();
            }
        });
    }



    @Override
    public void onMapReady(GoogleMap googleMap) {
        System.out.println("Enter onMapReady!!!!");
        map = googleMap;

        getCurrentLoction();

        map.setOnMapLongClickListener(this);
        map.setOnMarkerDragListener(this);



    }

   public void getCurrentLoction()
   {
       if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
           // TODO: Consider calling
           //    ActivityCompat#requestPermissions
           // here to request the missing permissions, and then overriding
           //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
           //                                          int[] grantResults)
           // to handle the case where the user grants the permission. See the documentation
           // for ActivityCompat#requestPermissions for more details.
           return;
       }

       lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3600000, 0, new LocationListener() {
           @Override
           public void onLocationChanged(Location location) {
               System.out.println("onChangeListener Enter!!!!");
               map.clear();

               if(currentmarker!=null)
                   currentmarker.remove();

               MarkerOptions mp = new MarkerOptions();

               mp.position(new LatLng(location.getLatitude(), location.getLongitude()));


              currentmarker= map.addMarker(mp);

                saveAddress(currentmarker);

               float zoomLevel = 21.0f; //This goes up to 21

               map.animateCamera(CameraUpdateFactory.newLatLngZoom(
                       new LatLng(location.getLatitude(), location.getLongitude()), zoomLevel));

               map.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                   @Override
                   public boolean onMarkerClick(Marker marker) {

                       marker.setTitle(getAddress(new LatLng(marker.getPosition().latitude,marker.getPosition().longitude)));
                       marker.showInfoWindow();
                       marker.setDraggable(true);
                       currentmarker=marker;
                       saveAddress(marker);
                       return true;

                   }
               });


           }

           @Override
           public void onStatusChanged(String provider, int status, Bundle extras) {

           }

           @Override
           public void onProviderEnabled(String provider) {

           }

           @Override
           public void onProviderDisabled(String provider) {

           }

       });


   }



   public String getAddress(LatLng latLng)
   {
       Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
       List<Address> addresses=null;
       try {
           addresses = geocoder.getFromLocation(latLng.latitude,latLng.longitude, 1); //1 num of possible location returned                        }

       }catch (Exception e)
       {
           System.out.println("Error while getting address of marker");
       }

       String address = addresses.get(0).getAddressLine(0); //0 to obtain first possible address
       String city = addresses.get(0).getLocality();
       String state = addresses.get(0).getAdminArea();
       String country = addresses.get(0).getCountryName();
       String postalCode = addresses.get(0).getPostalCode();
       //create your custom title
       String title = address+"-"+city+"-"+state;
       return title;

   }

    @Override
    public void onMarkerDragStart(Marker marker) {
        marker.setTitle(getAddress(new LatLng(marker.getPosition().latitude,marker.getPosition().longitude)));
        currentmarker=marker;
        marker.showInfoWindow();
        saveAddress(marker);
    }

    @Override
    public void onMarkerDrag(Marker marker) {
        marker.setTitle(getAddress(new LatLng(marker.getPosition().latitude,marker.getPosition().longitude)));
        currentmarker=marker;
        marker.showInfoWindow();
        saveAddress(marker);
    }

    @Override
    public void onMarkerDragEnd(Marker marker) {
     marker.setTitle(getAddress(new LatLng(marker.getPosition().latitude,marker.getPosition().longitude)));
     currentmarker=marker;
        marker.showInfoWindow();
       saveAddress(marker);
    }

    @Override
    public void onMapLongClick(LatLng latLng) {
       if(currentmarker!=null)
           currentmarker.remove();

       MarkerOptions markerOptions=new MarkerOptions();
       currentmarker= map.addMarker(markerOptions.position(latLng).title(getAddress(latLng)).draggable(true));


    }

    public void saveAddress(Marker marker)
    {
        user=new User(getApplicationContext());
        String address=getAddress(new LatLng(marker.getPosition().latitude,marker.getPosition().longitude));
        user.setAddress(address);
        user.setLocation(Double.toString(marker.getPosition().latitude)+" "+Double.toString(marker.getPosition().longitude));
        intent.putExtra("address",address);
    }
}
