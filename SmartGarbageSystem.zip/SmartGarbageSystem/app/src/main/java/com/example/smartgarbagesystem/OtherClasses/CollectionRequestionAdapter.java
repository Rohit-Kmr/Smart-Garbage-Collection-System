package com.example.smartgarbagesystem.OtherClasses;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.smartgarbagesystem.R;

import java.util.List;

public class CollectionRequestionAdapter extends ArrayAdapter<CollectionRequestSetGetClass> {

    private Context context=null;
    int mResource;

    public CollectionRequestionAdapter(Context context, int resource, List<CollectionRequestSetGetClass> objects) {
        super(context, resource, objects);
        this.context = context;
        mResource=resource;

    }



    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater=LayoutInflater.from(context);
        convertView=inflater.inflate(mResource,parent,false);

        String username=getItem(position).getUsername();
        String address=getItem(position).getAddress();
        String collectionDate=getItem(position).getCollectiondate();

        //Create the history object with information
        //IndividualHistorySetGetClass history=new IndividualHistorySetGetClass(username,location,collectionDate);

         CollectionRequestSetGetClass request =new CollectionRequestSetGetClass(username,address,collectionDate);

        TextView textName= convertView.findViewById(R.id.textName);
        TextView textAddress=convertView.findViewById(R.id.textAddress);
        TextView textcollectdate=convertView.findViewById(R.id.textCollectionDate2);


        textName.setText(username);
        textAddress.setText(address);
        textcollectdate.setText(collectionDate);

        return convertView;

    }

}
