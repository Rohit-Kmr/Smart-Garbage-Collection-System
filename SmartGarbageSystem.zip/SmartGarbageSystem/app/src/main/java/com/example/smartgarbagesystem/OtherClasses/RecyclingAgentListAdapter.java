package com.example.smartgarbagesystem.OtherClasses;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smartgarbagesystem.R;

import java.util.ArrayList;
import java.util.List;


public class RecyclingAgentListAdapter extends ArrayAdapter<RecylingAgentListSetGetClass> {

    static String number;
    private onTextSelected listener;     //reference of interface onFragmentSelected Listener
    private Context context=null;
    int mResource;
    TextView textView=null;
    View view1=null;
    public RecyclingAgentListAdapter(Context context, int resource, List<RecylingAgentListSetGetClass> objects) {
        super(context, resource, objects);
        this.context = context;
        this.mResource = resource;
    }

   //public void setContext(Context context1)
  // {
  //     this.context1=context1;
  // }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater=LayoutInflater.from(context);

        convertView=inflater.inflate(mResource,parent,false);

        String username=getItem(position).getName();
        String address=getItem(position).getAddress();
        String phone=getItem(position).getPhonenumber();

        //Create the history object with information
        //IndividualHistorySetGetClass history=new IndividualHistorySetGetClass(username,location,collectionDate);

        RecylingAgentListSetGetClass request =new RecylingAgentListSetGetClass(username,address,phone);

        TextView textName= convertView.findViewById(R.id.textRecyclerAgentName2);
        TextView textAddress=convertView.findViewById(R.id.textAddress2);
        final TextView textPhone=convertView.findViewById(R.id.textRecyclerPhone2);


        textName.setText(username);
        textAddress.setText(address);
        textPhone.setText(phone);
        //convertView;

        textPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                System.out.println("enter click listener!!!!");
                        //listener.onTextClick();
                       // number=textPhone.getText().toString();
                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("PhoneNumber", textPhone.getText().toString());
                clipboard.setPrimaryClip(clip);
                Toast.makeText(getContext().getApplicationContext(),"Copied",Toast.LENGTH_SHORT).show();
              /*  Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                callIntent.setData(Uri.parse("9811118142"));

                context.startActivity(callIntent);*/

            }
        });
        return convertView;

    }

    public  interface  onTextSelected
    {
        public void onTextClick();
    }



}
