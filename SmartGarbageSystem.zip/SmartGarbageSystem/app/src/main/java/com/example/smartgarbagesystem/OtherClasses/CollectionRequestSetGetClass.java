package com.example.smartgarbagesystem.OtherClasses;

public class CollectionRequestSetGetClass {
    private String username;
    private String Address;
    private String collectiondate;


    public CollectionRequestSetGetClass(String username, String address, String collectiondate) {
        this.username = username;
        Address = address;
        this.collectiondate = collectiondate;
    }


    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }


    public String getCollectiondate() {
        return collectiondate;
    }

    public void setCollectiondate(String collectiondate) {
        this.collectiondate = collectiondate;
    }
}
