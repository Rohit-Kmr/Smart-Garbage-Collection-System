package com.example.smartgarbagesystem.Login;

public class Validate{

    public static boolean checkUserName(String name)
    {
        if(!name.equals(""))
        {
         return true;
        }
        return false;
    }

    public static boolean checkPassword(String password)
    {
        if(!password.equals(""))
        {
            return true;
        }

        return false;
    }

    public static boolean checkUserType(String user)
    {
        if(user.equals("Individual")||user.equals("Collector Agent")||user.equals("Recycling Agent"))
            return true;
        return false;
    }

}
