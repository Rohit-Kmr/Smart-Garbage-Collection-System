package com.example.smartgarbagesystem.Login;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.google.firebase.database.DatabaseReference;
import com.example.smartgarbagesystem.R;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;


public class SignupActivity extends AppCompatActivity {

    String userName="";
    String email="";
    String password="";
    String rePassword="";
    String userType="";
    TextView textView=null;
     CheckBox checkBox=null;
     EditText editText1=null;
     EditText editText2=null;
    AutoCompleteTextView textViewList;
     Button button=null;
    String[] UserTypeList = new String[] {"Individual","Collector Agent","Recycling Agent"};
    ArrayList<String> UniqueID=new ArrayList<String>();
    private DatabaseReference mDatabase=null;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        editText1=findViewById(R.id.userEdit1);
        if(editText1!=null)
        userName= editText1.getText().toString();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.select_dialog_item, UserTypeList);
        textViewList =findViewById(R.id.autoCompleteTextview);
        textViewList.setThreshold(1);
        textViewList.setAdapter(adapter);
        checkBox=findViewById(R.id.checkbox1);

       textView=findViewById(R.id.textAlreadyAccount);
       textView.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent =new Intent(getApplicationContext(),SigninActivity.class);
               startActivity(intent);

           }
       });

        mDatabase = FirebaseDatabase.getInstance().getReference();

       button=findViewById(R.id.signupButton);
       button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               editText1=findViewById(R.id.userEdit1);
               if(editText1!=null)
                   userName= editText1.getText().toString();

               editText2=findViewById(R.id.emailEdit1);
               if(editText2!=null)
                   email=editText2.getText().toString();

               editText2=findViewById(R.id.passwordEdit1);
               if(editText2!=null)
                   password=editText2.getText().toString();

               editText2=findViewById(R.id.retypepasswordEdit1);
               if(editText2!=null)
                   rePassword=editText2.getText().toString();

                    userType=textViewList.getText().toString();

               if(userName.equals("")||email.equals("")||password.equals("")||userType.equals(""))
               {
                   if(userName.equals("")) {Log.i("msg:","username is empty");}
                   if(email.equals("")) {Log.i("msg:","email is empty");}
                   if(password.equals("")) {Log.i("msg:","password is empty");}
                   Toast.makeText(SignupActivity.this,"pls fill the all details",Toast.LENGTH_SHORT).show();
               }
               else if(!password.equals(rePassword))
               {
                   Toast.makeText(SignupActivity.this,"Password does not match",Toast.LENGTH_SHORT).show();
               }
               else if(!(userType.equals("Individual")||userType.equals("Collector Agent")||userType.equals("Recycling Agent")))
               {
                   Toast.makeText(SignupActivity.this,"User Type is not valid",Toast.LENGTH_SHORT).show();
               }
               else
               {
                   if(checkBox.isChecked())
                   {

                       if(Validate.checkUserName(userName)&&Validate.checkPassword(password)&&Validate.checkUserType(userType))
                       {
                               User user=new User(SignupActivity.this);
                               user.setUsername(userName);
                               user.setPassword(password);
                               user.setUserType(userType);
                               String id=generateUniqueID();
                               user.setId(id);

                               mDatabase.child("user").child(userType).child(id).child("username").setValue(userName);
                               mDatabase.child("user").child(userType).child(id).child("password").setValue(password);

                               if(userType.equals("Individual"))
                               mDatabase.child("user").child(userType).child(id).child("bin status").setValue("error");

                               mDatabase.child("user").child(userType).child(id).child("address").setValue("");
                               startActivity(new Intent(getApplicationContext(),SigninActivity.class));

                       }
                       else
                       {
                           Toast.makeText(SignupActivity.this,"Input data is not valid !!!!",Toast.LENGTH_SHORT).show();
                       }

                   }

               }
           }
       });


}


    public String generateUniqueID()
    {
        Random rand = new Random();
        int flag=0;
        String id="";
        while(flag==0) {
            flag=1;
            System.out.println("enter 4");
            int rand_int1= rand.nextInt(1000);
            id=Integer.toString(rand_int1);
            for (int i = 0; i < UniqueID.size(); i++) {
                if (UniqueID.get(i).equals(id))
                {
                    flag=0;
                    break;
                }
            }
        }
        UniqueID.add(id);
        System.out.println("id:"+id);
        return id;
    }

}
