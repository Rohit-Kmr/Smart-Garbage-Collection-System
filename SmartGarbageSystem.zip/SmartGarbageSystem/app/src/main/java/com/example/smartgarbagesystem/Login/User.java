package com.example.smartgarbagesystem.Login;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;

public class User  {
   private String username="";
   private String password="";
   private String userType="";
    private String phone;
   private String email="";
   private  String Id;
    private String address;
    private String location;

    public String getSignal() {
        location=sharedPreferences.getString("signal","");
        return signal;
    }

    public void setSignal(String signal) {
        location=sharedPreferences.getString("Signal","");
        this.signal = signal;
    }

    private String signal;
    Context context;



    public String getLocation() {
        location=sharedPreferences.getString("location","");
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
        sharedPreferences.edit().putString("location",location).commit();
    }




    SharedPreferences sharedPreferences; //interface
    public User(Context context) {
        this.context=context;
        sharedPreferences=context.getSharedPreferences("login_datails",context.MODE_PRIVATE);
    }


    public String getUsername() {
        username=sharedPreferences.getString("username","");
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
        sharedPreferences.edit().putString("username",username).commit();
    }

    public String getPassword() {
        password=sharedPreferences.getString("password","");
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
        sharedPreferences.edit().putString("password",password).commit();
    }


    public String getUserType() {
        userType=sharedPreferences.getString("userType","");
        return userType;
    }

    public void setUserType(String usertype) {
        this.userType = usertype;
        sharedPreferences.edit().putString("userType",userType).commit();
    }

    public void removeUser()
    {
        sharedPreferences.edit().clear().commit();
    }

    public void setId(String id)
    {
        this.Id=id;
        sharedPreferences.edit().putString("Id",id).commit();
    }

    public String getId()
    {
        Id=sharedPreferences.getString("Id","");
        return Id;
    }

    public String getEmail() {
        email=sharedPreferences.getString("email","");
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
        sharedPreferences.edit().putString("email",email).commit();
    }



    public String getPhone() {
        phone=sharedPreferences.getString("phone","");

        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
        sharedPreferences.edit().putString("phone",phone).commit();
    }

    public String getAddress() {
        address=sharedPreferences.getString("address","");
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
        sharedPreferences.edit().putString("address",address).commit();
    }


}
