package com.example.smartgarbagesystem.OtherClasses;

public class CollectionExtraRequestSetGetClass {
    private String username;
    private String requestItem;
    private  String requestItemName;
    private String requestItemDescription;
    private  String collectiondate;

    public CollectionExtraRequestSetGetClass(String username, String requestItem, String requestItemName, String requestItemDescription, String collectiondate) {
        this.username = username;
        this.requestItem = requestItem;
        this.requestItemName = requestItemName;
        this.requestItemDescription = requestItemDescription;
        this.collectiondate = collectiondate;
    }

    public String getCollectiondate() {
        return collectiondate;
    }

    public void setCollectiondate(String collectiondate) {
        this.collectiondate = collectiondate;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRequestItem() {
        return requestItem;
    }

    public void setRequestItem(String requestItem) {
        this.requestItem = requestItem;
    }

    public String getRequestItemName() {
        return requestItemName;
    }

    public void setRequestItemName(String requestItemName) {
        this.requestItemName = requestItemName;
    }

    public String getRequestItemDescription() {
        return requestItemDescription;
    }

    public void setRequestItemDescription(String requestItemDescription) {
        this.requestItemDescription = requestItemDescription;
    }
}
