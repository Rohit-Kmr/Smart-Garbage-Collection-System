package com.example.smartgarbagesystem.OtherClasses;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.smartgarbagesystem.R;

import java.util.List;

public class UpcomingScheduleAdapter extends ArrayAdapter<UpcomingScheduleSetGetClass> {
    private Context context=null;
    int mResource;

    public UpcomingScheduleAdapter(Context context, int resource, List<UpcomingScheduleSetGetClass> objects) {
        super(context, resource, objects);
        this.context = context;
        mResource=resource;

    }



    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater=LayoutInflater.from(context);
        convertView=inflater.inflate(mResource,parent,false);

        String requestType=getItem(position).getRequestType();
        String username=getItem(position).getUsername();
        String collectionDate=getItem(position).getCollectionDate();

        //Create the history object with information
        UpcomingScheduleSetGetClass history=new UpcomingScheduleSetGetClass(requestType,username,collectionDate);



        TextView textrequest= convertView.findViewById(R.id.textRequestType);
        TextView textuser=convertView.findViewById(R.id.textUsername2);
        TextView textCollectionDate=convertView.findViewById(R.id.textCollectionDate2);

        textrequest.setText(requestType);
        textuser.setText(username);
        textCollectionDate.setText(collectionDate);

        return convertView;

    }
}
