package com.example.smartgarbagesystem.OtherClasses;

public class RecyclerHistorySetGetClass {
    private String userType;
    private  String username;
    private  String phone;


    public RecyclerHistorySetGetClass(String userType, String username, String phone) {
        this.userType = userType;
        this.username = username;
        this.phone = phone;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
